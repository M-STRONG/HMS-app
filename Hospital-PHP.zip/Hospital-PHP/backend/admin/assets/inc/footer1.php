<footer class="footer footer-alt">
    2024 - <?php echo date('Y'); ?> &copy; Hospital Management System</a>
</footer>